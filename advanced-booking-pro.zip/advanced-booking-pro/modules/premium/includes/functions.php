<?php
/**
 * Functions
 *
 * @package YITH\Booking\Modules\Premium
 */

defined( 'YITH_WCBK' ) || exit;

require_once __DIR__ . '/functions.templates.php';
