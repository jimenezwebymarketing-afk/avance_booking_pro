/**
 * Advanced Booking Pro - Frontend JavaScript
 * Interacciones modernas estilo TripAdvisor/Viator
 * 
 * @package AdvancedBookingPro
 * @version 1.0.0
 */

(function($) {
    'use strict';

    /**
     * Clase principal para el formulario de reservas
     */
    class AdvancedBookingForm {
        constructor(element) {
            this.$form = $(element);
            this.productId = this.$form.data('product-id');
            this.bookingData = {
                from: null,
                to: null,
                duration: 0,
                persons: {},
                resources: [],
                services: [],
                price: 0
            };
            
            this.init();
        }

        /**
         * Inicializa el formulario
         */
        init() {
            this.initDatePicker();
            this.initPersonSelector();
            this.initResourceSelector();
            this.initServiceSelector();
            this.initPriceCalculator();
            this.initFormValidation();
            this.initAnimations();
            
            console.log('Advanced Booking Pro Form initialized');
        }

        /**
         * Inicializa el selector de fechas
         */
        initDatePicker() {
            const self = this;
            const $dateInputs = this.$form.find('.abp-date-input');
            const $calendar = this.$form.find('.abp-calendar-dropdown');

            // Mostrar/ocultar calendario
            $dateInputs.on('click', function() {
                const $input = $(this);
                const $container = $input.closest('.abp-date-picker-container');
                const $dropdown = $container.find('.abp-calendar-dropdown');
                
                // Cerrar otros calendarios abiertos
                $('.abp-calendar-dropdown').not($dropdown).removeClass('active');
                
                // Toggle este calendario
                $dropdown.toggleClass('active');
                
                // Posicionar calendario
                self.positionCalendar($dropdown, $input);
            });

            // Cerrar calendario al hacer click fuera
            $(document).on('click', function(e) {
                if (!$(e.target).closest('.abp-date-picker-container').length) {
                    $('.abp-calendar-dropdown').removeClass('active');
                }
            });

            // Navegación del calendario
            this.$form.on('click', '.abp-calendar-nav-btn', function(e) {
                e.stopPropagation();
                const direction = $(this).data('direction');
                self.navigateCalendar(direction);
            });

            // Selección de día
            this.$form.on('click', '.abp-calendar-day:not(.disabled):not(.unavailable)', function(e) {
                e.stopPropagation();
                const $day = $(this);
                const date = $day.data('date');
                
                self.selectDate(date, $day);
            });

            // Inicializar calendario con el mes actual
            this.renderCalendar(new Date());
        }

        /**
         * Renderiza el calendario
         */
        renderCalendar(date) {
            const self = this;
            const year = date.getFullYear();
            const month = date.getMonth();
            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);
            const prevLastDay = new Date(year, month, 0);
            const startDay = firstDay.getDay();
            const endDate = lastDay.getDate();
            const prevEndDate = prevLastDay.getDate();
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            // Actualizar título del mes
            const monthNames = [
                'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
            ];
            this.$form.find('.abp-calendar-month').text(`${monthNames[month]} ${year}`);

            // Limpiar grid
            const $grid = this.$form.find('.abp-calendar-grid');
            $grid.find('.abp-calendar-day').remove();

            // Renderizar días del mes anterior
            for (let i = startDay - 1; i >= 0; i--) {
                const day = prevEndDate - i;
                this.addCalendarDay($grid, day, new Date(year, month - 1, day), 'disabled');
            }

            // Renderizar días del mes actual
            for (let day = 1; day <= endDate; day++) {
                const currentDate = new Date(year, month, day);
                const dateStr = this.formatDate(currentDate);
                
                // Verificar disponibilidad
                this.checkAvailability(dateStr).then(available => {
                    const classes = [];
                    
                    if (currentDate.getTime() === today.getTime()) {
                        classes.push('today');
                    }
                    
                    if (currentDate < today) {
                        classes.push('disabled');
                    } else if (!available) {
                        classes.push('unavailable');
                    } else {
                        classes.push('available');
                    }
                    
                    // Verificar si está seleccionado
                    if (this.bookingData.from && dateStr === this.bookingData.from) {
                        classes.push('selected');
                    }
                    if (this.bookingData.to && dateStr === this.bookingData.to) {
                        classes.push('selected');
                    }
                    
                    // Verificar si está en rango
                    if (this.isInRange(currentDate)) {
                        classes.push('in-range');
                    }
                    
                    this.addCalendarDay($grid, day, currentDate, classes.join(' '));
                });
            }

            // Renderizar días del mes siguiente
            const nextDays = 42 - (startDay + endDate); // 6 filas x 7 días = 42
            for (let day = 1; day <= nextDays; day++) {
                this.addCalendarDay($grid, day, new Date(year, month + 1, day), 'disabled');
            }

            // Guardar fecha actual del calendario
            this.currentCalendarDate = date;
        }

        /**
         * Añade un día al calendario
         */
        addCalendarDay($grid, day, date, classes) {
            const dateStr = this.formatDate(date);
            const price = this.getDayPrice(dateStr);
            
            const $day = $(`
                <div class="abp-calendar-day ${classes}" data-date="${dateStr}">
                    <span>${day}</span>
                    ${price ? `<span class="abp-day-price">${price}</span>` : ''}
                </div>
            `);
            
            $grid.append($day);
        }

        /**
         * Navega el calendario
         */
        navigateCalendar(direction) {
            const currentDate = this.currentCalendarDate || new Date();
            let newDate;
            
            if (direction === 'prev') {
                newDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1);
            } else {
                newDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1);
            }
            
            this.renderCalendar(newDate);
        }

        /**
         * Selecciona una fecha
         */
        selectDate(dateStr, $day) {
            if (!this.bookingData.from || (this.bookingData.from && this.bookingData.to)) {
                // Seleccionar fecha de inicio
                this.bookingData.from = dateStr;
                this.bookingData.to = null;
                this.$form.find('.abp-date-input[name="from"]').val(this.formatDateDisplay(dateStr));
                this.$form.find('.abp-date-input[name="to"]').val('');
            } else {
                // Seleccionar fecha de fin
                const fromDate = new Date(this.bookingData.from);
                const toDate = new Date(dateStr);
                
                if (toDate > fromDate) {
                    this.bookingData.to = dateStr;
                    this.$form.find('.abp-date-input[name="to"]').val(this.formatDateDisplay(dateStr));
                    
                    // Cerrar calendario
                    $('.abp-calendar-dropdown').removeClass('active');
                    
                    // Calcular duración
                    this.calculateDuration();
                    
                    // Recalcular precio
                    this.calculatePrice();
                } else {
                    // Si la fecha de fin es anterior, reiniciar
                    this.bookingData.from = dateStr;
                    this.bookingData.to = null;
                    this.$form.find('.abp-date-input[name="from"]').val(this.formatDateDisplay(dateStr));
                    this.$form.find('.abp-date-input[name="to"]').val('');
                }
            }
            
            // Re-renderizar calendario
            this.renderCalendar(this.currentCalendarDate);
        }

        /**
         * Verifica si una fecha está en el rango seleccionado
         */
        isInRange(date) {
            if (!this.bookingData.from || !this.bookingData.to) {
                return false;
            }
            
            const fromDate = new Date(this.bookingData.from);
            const toDate = new Date(this.bookingData.to);
            
            return date > fromDate && date < toDate;
        }

        /**
         * Inicializa el selector de personas
         */
        initPersonSelector() {
            const self = this;
            
            // Botones de incrementar/decrementar
            this.$form.on('click', '.abp-quantity-btn', function() {
                const $btn = $(this);
                const action = $btn.data('action');
                const personType = $btn.data('person-type');
                const $display = $btn.siblings('.abp-quantity-display');
                const $minusBtn = $btn.siblings('[data-action="minus"]');
                const $plusBtn = $btn.siblings('[data-action="plus"]');
                
                let currentValue = parseInt($display.text()) || 0;
                const min = parseInt($btn.closest('.abp-person-type').data('min')) || 0;
                const max = parseInt($btn.closest('.abp-person-type').data('max')) || 999;
                
                if (action === 'minus' && currentValue > min) {
                    currentValue--;
                } else if (action === 'plus' && currentValue < max) {
                    currentValue++;
                }
                
                // Actualizar display
                $display.text(currentValue);
                
                // Actualizar botones
                $minusBtn.prop('disabled', currentValue <= min);
                $plusBtn.prop('disabled', currentValue >= max);
                
                // Animar cambio
                $display.addClass('abp-animate-scale-in');
                setTimeout(() => $display.removeClass('abp-animate-scale-in'), 300);
                
                // Guardar en datos de reserva
                self.bookingData.persons[personType] = currentValue;
                
                // Recalcular precio
                self.calculatePrice();
            });
        }

        /**
         * Inicializa el selector de recursos
         */
        initResourceSelector() {
            const self = this;
            
            this.$form.on('click', '.abp-resource-card', function() {
                const $card = $(this);
                const resourceId = $card.data('resource-id');
                const multiSelect = $card.closest('.abp-resources-selector').data('multi-select');
                
                if (multiSelect) {
                    // Permitir selección múltiple
                    $card.toggleClass('selected');
                    
                    if ($card.hasClass('selected')) {
                        if (!self.bookingData.resources.includes(resourceId)) {
                            self.bookingData.resources.push(resourceId);
                        }
                    } else {
                        const index = self.bookingData.resources.indexOf(resourceId);
                        if (index > -1) {
                            self.bookingData.resources.splice(index, 1);
                        }
                    }
                } else {
                    // Selección única
                    $('.abp-resource-card').removeClass('selected');
                    $card.addClass('selected');
                    self.bookingData.resources = [resourceId];
                }
                
                // Animar
                $card.addClass('abp-animate-scale-in');
                setTimeout(() => $card.removeClass('abp-animate-scale-in'), 300);
                
                // Recalcular precio
                self.calculatePrice();
            });
        }

        /**
         * Inicializa el selector de servicios
         */
        initServiceSelector() {
            const self = this;
            
            this.$form.on('click', '.abp-service-item', function() {
                const $item = $(this);
                const serviceId = $item.data('service-id');
                
                $item.toggleClass('selected');
                
                if ($item.hasClass('selected')) {
                    if (!self.bookingData.services.includes(serviceId)) {
                        self.bookingData.services.push(serviceId);
                    }
                } else {
                    const index = self.bookingData.services.indexOf(serviceId);
                    if (index > -1) {
                        self.bookingData.services.splice(index, 1);
                    }
                }
                
                // Animar
                $item.addClass('abp-animate-scale-in');
                setTimeout(() => $item.removeClass('abp-animate-scale-in'), 300);
                
                // Recalcular precio
                self.calculatePrice();
            });
        }

        /**
         * Inicializa el calculador de precios
         */
        initPriceCalculator() {
            // El precio se calculará en tiempo real con cada cambio
            this.calculatePrice();
        }

        /**
         * Calcula el precio total
         */
        calculatePrice() {
            const self = this;
            
            // Mostrar loading
            this.$form.find('.abp-price-summary').addClass('loading');
            
            // Hacer petición AJAX para calcular precio
            $.ajax({
                url: abp_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'abp_calculate_price',
                    nonce: abp_vars.nonce,
                    product_id: this.productId,
                    booking_data: this.bookingData
                },
                success: function(response) {
                    if (response.success) {
                        self.updatePriceSummary(response.data);
                        self.bookingData.price = response.data.total;
                    } else {
                        self.showMessage('error', response.data.message || 'Error al calcular precio');
                    }
                },
                error: function() {
                    self.showMessage('error', 'Error de conexión al calcular precio');
                },
                complete: function() {
                    self.$form.find('.abp-price-summary').removeClass('loading');
                }
            });
        }

        /**
         * Actualiza el resumen de precio
         */
        updatePriceSummary(priceData) {
            const $breakdown = this.$form.find('.abp-price-breakdown');
            const $total = this.$form.find('.abp-price-total-amount');
            
            // Limpiar breakdown anterior
            $breakdown.empty();
            
            // Añadir líneas de precio
            if (priceData.breakdown) {
                priceData.breakdown.forEach(item => {
                    const isDiscount = item.value < 0;
                    const $line = $(`
                        <div class="abp-price-line ${isDiscount ? 'discount' : ''}">
                            <span class="abp-price-line-label">${item.label}</span>
                            <span class="abp-price-line-value">${this.formatPrice(Math.abs(item.value))}</span>
                        </div>
                    `);
                    $breakdown.append($line);
                });
            }
            
            // Actualizar total con animación
            const currentTotal = parseFloat($total.find('.abp-price-amount').text().replace(/[^0-9.]/g, '')) || 0;
            const newTotal = priceData.total;
            
            this.animateValue($total.find('.abp-price-amount'), currentTotal, newTotal, 500);
        }

        /**
         * Anima un valor numérico
         */
        animateValue($element, start, end, duration) {
            const startTime = Date.now();
            const self = this;
            
            const animate = function() {
                const now = Date.now();
                const progress = Math.min((now - startTime) / duration, 1);
                const value = start + (end - start) * progress;
                
                $element.text(self.formatPrice(value));
                
                if (progress < 1) {
                    requestAnimationFrame(animate);
                }
            };
            
            animate();
        }

        /**
         * Inicializa validación del formulario
         */
        initFormValidation() {
            const self = this;
            
            this.$form.on('submit', function(e) {
                e.preventDefault();
                
                if (self.validateForm()) {
                    self.submitBooking();
                }
            });
        }

        /**
         * Valida el formulario
         */
        validateForm() {
            let isValid = true;
            const errors = [];
            
            // Validar fechas
            if (!this.bookingData.from) {
                errors.push('Por favor selecciona una fecha de inicio');
                isValid = false;
            }
            
            if (!this.bookingData.to) {
                errors.push('Por favor selecciona una fecha de fin');
                isValid = false;
            }
            
            // Validar personas
            const totalPersons = Object.values(this.bookingData.persons).reduce((a, b) => a + b, 0);
            if (totalPersons === 0) {
                errors.push('Por favor selecciona al menos una persona');
                isValid = false;
            }
            
            // Mostrar errores
            if (!isValid) {
                this.showMessage('error', errors.join('<br>'));
            }
            
            return isValid;
        }

        /**
         * Envía la reserva
         */
        submitBooking() {
            const self = this;
            const $button = this.$form.find('.abp-submit-button');
            
            // Mostrar loading
            $button.addClass('loading').prop('disabled', true);
            
            $.ajax({
                url: abp_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'abp_add_to_cart',
                    nonce: abp_vars.nonce,
                    product_id: this.productId,
                    booking_data: this.bookingData
                },
                success: function(response) {
                    if (response.success) {
                        self.showMessage('success', 'Reserva añadida al carrito exitosamente');
                        
                        // Redirigir al carrito después de 1 segundo
                        setTimeout(() => {
                            window.location.href = abp_vars.cart_url;
                        }, 1000);
                    } else {
                        self.showMessage('error', response.data.message || 'Error al procesar la reserva');
                        $button.removeClass('loading').prop('disabled', false);
                    }
                },
                error: function() {
                    self.showMessage('error', 'Error de conexión al procesar la reserva');
                    $button.removeClass('loading').prop('disabled', false);
                }
            });
        }

        /**
         * Inicializa animaciones
         */
        initAnimations() {
            // Observador de intersección para animaciones al hacer scroll
            if ('IntersectionObserver' in window) {
                const observer = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            $(entry.target).addClass('abp-animate-fade-in');
                        }
                    });
                }, {
                    threshold: 0.1
                });
                
                this.$form.find('.abp-form-section').each(function() {
                    observer.observe(this);
                });
            }
        }

        /**
         * Muestra un mensaje
         */
        showMessage(type, message) {
            const icons = {
                success: '✓',
                error: '✕',
                warning: '⚠',
                info: 'ℹ'
            };
            
            const $message = $(`
                <div class="abp-message ${type} abp-animate-slide-in">
                    <div class="abp-message-icon">${icons[type]}</div>
                    <div class="abp-message-content">
                        <div class="abp-message-text">${message}</div>
                    </div>
                </div>
            `);
            
            // Remover mensajes anteriores
            this.$form.find('.abp-message').remove();
            
            // Añadir nuevo mensaje
            this.$form.prepend($message);
            
            // Auto-remover después de 5 segundos
            setTimeout(() => {
                $message.fadeOut(300, function() {
                    $(this).remove();
                });
            }, 5000);
        }

        /**
         * Funciones auxiliares
         */
        
        checkAvailability(date) {
            // En producción, esto haría una petición AJAX real
            // Por ahora, retornamos una promesa que resuelve true
            return Promise.resolve(true);
        }

        getDayPrice(date) {
            // En producción, esto obtendría el precio real del día
            // Por ahora, retornamos null
            return null;
        }

        calculateDuration() {
            if (this.bookingData.from && this.bookingData.to) {
                const from = new Date(this.bookingData.from);
                const to = new Date(this.bookingData.to);
                const diffTime = Math.abs(to - from);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                this.bookingData.duration = diffDays;
            }
        }

        formatDate(date) {
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        }

        formatDateDisplay(dateStr) {
            const date = new Date(dateStr);
            const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
            return `${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
        }

        formatPrice(value) {
            return new Intl.NumberFormat('es-ES', {
                style: 'currency',
                currency: abp_vars.currency || 'EUR'
            }).format(value);
        }

        positionCalendar($dropdown, $input) {
            const inputRect = $input[0].getBoundingClientRect();
            const dropdownHeight = $dropdown.outerHeight();
            const windowHeight = $(window).height();
            
            // Verificar si hay espacio debajo
            if (inputRect.bottom + dropdownHeight > windowHeight) {
                // Mostrar arriba
                $dropdown.css({
                    bottom: '100%',
                    top: 'auto',
                    marginTop: 0,
                    marginBottom: '0.5rem'
                });
            } else {
                // Mostrar debajo
                $dropdown.css({
                    top: '100%',
                    bottom: 'auto',
                    marginTop: '0.5rem',
                    marginBottom: 0
                });
            }
        }
    }

    /**
     * Inicializar formularios cuando el DOM esté listo
     */
    $(document).ready(function() {
        $('.abp-booking-form').each(function() {
            new AdvancedBookingForm(this);
        });
    });

    /**
     * Exponer la clase globalmente para extensiones
     */
    window.AdvancedBookingForm = AdvancedBookingForm;

})(jQuery);
