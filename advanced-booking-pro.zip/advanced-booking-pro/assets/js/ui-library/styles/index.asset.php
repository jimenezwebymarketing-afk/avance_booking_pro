<?php return array('dependencies' => array('lodash', 'react', 'wp-element', 'wp-polyfill'), 'version' => '7cd9ee4e60f17d808251');
