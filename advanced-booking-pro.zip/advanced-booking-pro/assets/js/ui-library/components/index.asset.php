<?php return array('dependencies' => array('lodash', 'react', 'react-dom', 'wp-data', 'wp-date', 'wp-element', 'wp-i18n', 'wp-polyfill', 'yith-wcbk-ui-styles'), 'version' => '086ad0b7321589c7182c');
