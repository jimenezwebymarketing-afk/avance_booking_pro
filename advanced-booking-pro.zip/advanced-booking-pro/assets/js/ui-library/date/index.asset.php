<?php return array('dependencies' => array('wp-date', 'wp-polyfill'), 'version' => '33f8eb01b5904eb44f06');
