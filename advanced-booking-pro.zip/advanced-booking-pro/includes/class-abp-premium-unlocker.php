<?php
/**
 * Advanced Booking Pro - Premium Unlocker
 * Desbloquea todas las funcionalidades premium del plugin
 * 
 * @package AdvancedBookingPro
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Clase para desbloquear funciones premium
 */
class ABP_Premium_Unlocker {
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->init_hooks();
    }
    
    /**
     * Inicializa los hooks
     */
    private function init_hooks() {
        // Siempre retornar que la licencia es válida
        add_filter( 'pre_option_yith_wcbk_license_activation_email', array( $this, 'fake_license_email' ), 999 );
        add_filter( 'pre_option_yith_wcbk_license_activation_key', array( $this, 'fake_license_key' ), 999 );
        add_filter( 'yith_plugin_fw_licence_activation_check', '__return_true', 999 );
        add_filter( 'yith_wcbk_is_premium', '__return_true', 999 );
        add_filter( 'yith_wcbk_check_licence', '__return_true', 999 );
        
        // Desactivar verificaciones de licencia
        add_filter( 'pre_http_request', array( $this, 'block_license_checks' ), 10, 3 );
        
        // Habilitar todos los módulos
        add_filter( 'yith_wcbk_modules_to_load', array( $this, 'enable_all_modules' ), 999 );
        
        // Desactivar banners de upgrade
        add_action( 'admin_init', array( $this, 'remove_upgrade_notices' ), 999 );
        
        // Habilitar todas las funciones premium
        add_action( 'init', array( $this, 'enable_premium_features' ), 1 );
        
        // Remover límites
        add_filter( 'yith_wcbk_max_bookings_per_unit', '__return_false', 999 );
        add_filter( 'yith_wcbk_limit_check', '__return_false', 999 );
    }
    
    /**
     * Retorna un email de licencia falso
     */
    public function fake_license_email( $value ) {
        return 'premium@advancedbookingpro.local';
    }
    
    /**
     * Retorna una clave de licencia falsa
     */
    public function fake_license_key( $value ) {
        return 'ABP-PREMIUM-' . wp_generate_password( 20, false );
    }
    
    /**
     * Bloquea las peticiones de verificación de licencia
     */
    public function block_license_checks( $response, $args, $url ) {
        // Bloquear peticiones a servidores de licencias YITH
        if ( strpos( $url, 'yithemes.com' ) !== false || 
             strpos( $url, 'license' ) !== false || 
             strpos( $url, 'activation' ) !== false ) {
            
            // Retornar respuesta exitosa falsa
            return array(
                'response' => array(
                    'code' => 200,
                    'message' => 'OK',
                ),
                'body' => json_encode( array(
                    'success' => true,
                    'activated' => true,
                    'is_membership' => true,
                    'message' => 'License activated',
                ) ),
            );
        }
        
        return $response;
    }
    
    /**
     * Habilita todos los módulos
     */
    public function enable_all_modules( $modules ) {
        // Lista de todos los módulos disponibles
        $all_modules = array(
            'people',
            'resources',
            'services',
            'costs',
            'external-sync',
            'google-calendar',
            'google-maps',
            'search-forms',
            'premium',
        );
        
        // Asegurar que todos los módulos estén habilitados
        return $all_modules;
    }
    
    /**
     * Remueve notificaciones de upgrade
     */
    public function remove_upgrade_notices() {
        // Remover todos los avisos de actualización/upgrade
        remove_all_actions( 'admin_notices' );
        remove_all_actions( 'yith_plugin_fw_panel_wc_before_update' );
        remove_all_actions( 'yith_wcbk_premium_tab' );
        
        // Remover banners de licencia
        if ( class_exists( 'YITH_Plugin_Licence' ) ) {
            remove_action( 'admin_init', array( 'YITH_Plugin_Licence', 'add_action_links' ) );
        }
    }
    
    /**
     * Habilita todas las características premium
     */
    public function enable_premium_features() {
        // Definir constantes premium si no existen
        if ( ! defined( 'YITH_WCBK_PREMIUM' ) ) {
            define( 'YITH_WCBK_PREMIUM', true );
        }
        
        if ( ! defined( 'ABP_PREMIUM_ENABLED' ) ) {
            define( 'ABP_PREMIUM_ENABLED', true );
        }
        
        // Habilitar funciones específicas
        add_filter( 'yith_wcbk_enable_people_types', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_resources', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_services', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_google_calendar', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_external_sync', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_google_maps', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_search_forms', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_cost_rules', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_price_rules', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_booking_notes', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_booking_cancellation', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_booking_confirmation', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_availability_rules', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_buffer', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_time_slots', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_pdf_export', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_csv_export', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_ics_export', '__return_true', 999 );
        
        // Habilitar características avanzadas
        add_filter( 'yith_wcbk_enable_duration_range', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_weekly_discount', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_monthly_discount', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_last_minute_discount', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_deposits', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_extra_costs', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_booking_forms', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_checkin_checkout', '__return_true', 999 );
        
        // Habilitar integraciones
        add_filter( 'yith_wcbk_enable_wcml_integration', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_wpml_integration', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_polylang_integration', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_elementor_integration', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_divi_integration', '__return_true', 999 );
        add_filter( 'yith_wcbk_enable_wpbakery_integration', '__return_true', 999 );
        
        // Remover límites de funciones
        add_filter( 'yith_wcbk_max_bookings', '__return_false', 999 );
        add_filter( 'yith_wcbk_max_services', '__return_false', 999 );
        add_filter( 'yith_wcbk_max_resources', '__return_false', 999 );
        add_filter( 'yith_wcbk_max_people_types', '__return_false', 999 );
    }
}

// Inicializar el unlocker
new ABP_Premium_Unlocker();

/**
 * Funciones de ayuda para verificar si el premium está activo
 */

/**
 * Verifica si el plugin premium está activo
 * 
 * @return bool Siempre true
 */
function abp_is_premium() {
    return true;
}

/**
 * Verifica si una característica premium está disponible
 * 
 * @param string $feature Nombre de la característica
 * @return bool Siempre true
 */
function abp_is_feature_enabled( $feature ) {
    return true;
}

/**
 * Obtiene el estado de la licencia
 * 
 * @return array Estado de licencia simulado
 */
function abp_get_license_status() {
    return array(
        'activated' => true,
        'is_valid' => true,
        'is_membership' => true,
        'email' => 'premium@advancedbookingpro.local',
        'expires' => 'never',
        'status' => 'active',
        'message' => 'Premium version - All features unlocked',
    );
}

/**
 * Verifica si el módulo está disponible
 * 
 * @param string $module Nombre del módulo
 * @return bool Siempre true
 */
function abp_is_module_enabled( $module ) {
    return true;
}

/**
 * Obtiene la lista de módulos habilitados
 * 
 * @return array Lista de todos los módulos
 */
function abp_get_enabled_modules() {
    return array(
        'people',
        'resources',
        'services',
        'costs',
        'external-sync',
        'google-calendar',
        'google-maps',
        'search-forms',
        'premium',
    );
}

/**
 * Hook para reemplazar verificaciones de licencia en otros archivos
 */
add_filter( 'option_yith_wcbk_licence_status', function() {
    return 'activated';
}, 999 );

add_filter( 'option_yith_wcbk_licence_email', function() {
    return 'premium@advancedbookingpro.local';
}, 999 );

add_filter( 'option_yith_wcbk_licence_key', function() {
    return 'ABP-PREMIUM-UNLOCKED';
}, 999 );

// Remover acciones de actualización y verificación de licencia
remove_all_actions( 'yith_plugin_fw_get_field_licence-activation' );
remove_all_actions( 'yith_wcbk_check_licence' );
remove_all_actions( 'yith_licence_check_activation' );

/**
 * Desactivar completamente el sistema de licencias
 */
add_action( 'init', function() {
    // Remover clases de licencia si existen
    if ( class_exists( 'YITH_Plugin_Licence' ) ) {
        remove_action( 'admin_init', array( 'YITH_Plugin_Licence', 'check_activation' ) );
        remove_action( 'admin_init', array( 'YITH_Plugin_Licence', 'activate_licence' ) );
    }
    
    if ( class_exists( 'YITH_Licence' ) ) {
        remove_action( 'init', array( 'YITH_Licence', 'check' ) );
    }
}, 1 );

/**
 * Log para debugging (solo en modo debug)
 */
if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
    error_log( 'Advanced Booking Pro: Premium features unlocked' );
}
