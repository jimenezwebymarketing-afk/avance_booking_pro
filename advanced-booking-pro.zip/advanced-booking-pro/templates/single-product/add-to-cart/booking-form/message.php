<?php
/**
 * Booking form message template.
 *
 * @var WC_Product_Booking $product
 *
 * @package YITH\Booking\Templates
 */

defined( 'YITH_WCBK' ) || exit;
?>
<div class="yith-wcbk-booking-form-message"></div>
